package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity(), GameTask {
    lateinit var rootLayout: LinearLayout
    lateinit var startBtn: Button
    lateinit var mGameView: GameView
    lateinit var scoreTextView: TextView
    lateinit var highScoreTextView: TextView
    var highScore = 0 // New variable to store high score

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startBtn = findViewById(R.id.startBtn)
        rootLayout = findViewById(R.id.rootLayout)
        scoreTextView = findViewById(R.id.score)
        highScoreTextView = findViewById(R.id.highScore)
        mGameView = GameView(this, this)

        startBtn.setOnClickListener {
            mGameView.setBackgroundResource(R.drawable.road3)
            rootLayout.addView(mGameView)
            startBtn.visibility = View.GONE
            scoreTextView.visibility = View.GONE
            highScoreTextView.visibility = View.GONE
        }
    }

    override fun closeGame(mScore: Int) {
        scoreTextView.text = "Score : $mScore"
        if (mScore > highScore) {
            highScore = mScore
            highScoreTextView.text = "High Score : $highScore"
        }
        rootLayout.removeView(mGameView)
        startBtn.visibility = View.VISIBLE
        scoreTextView.visibility = View.VISIBLE
        highScoreTextView.visibility = View.VISIBLE
    }
}
