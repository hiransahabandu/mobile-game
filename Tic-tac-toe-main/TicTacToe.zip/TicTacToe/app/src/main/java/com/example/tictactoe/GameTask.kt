package com.example.tictactoe

interface GameTask {

    fun closeGame(mScore: Int)
}